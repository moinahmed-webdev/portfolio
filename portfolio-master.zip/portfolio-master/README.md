<h1 align="center">Portfolio Website</h1>
<h2 align="center">Dina Blaszczak | Front-End Developer </h2>
<p align="center">Live preview: <a href="https://themalni.github.io/portfolio">Portfolio Website</a></p><br>
<p align="center">
<img src="https://user-images.githubusercontent.com/12295765/43483406-dde55e8a-950b-11e8-8841-d616ee0c0551.jpg" width="550" alt="Portfolio Website">
</p>
